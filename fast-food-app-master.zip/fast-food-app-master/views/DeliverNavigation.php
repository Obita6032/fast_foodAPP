<div class="shadow-sm col-12">
  <div class="row">
    <div class="col-12">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
          <a class="navbar-brand"  aria-current="page" href="deliverRouter.php?page=deliverDashboard">Profile</a>
          <a class="navbar-brand" aria-current="page" href="deliverRouter.php?page=deliverPendingDelivery">Pending Oders</a>
          <a class="navbar-brand" aria-current="page" href="#">Complete Oders</a>
          <a class="btn btn-primary" href="deliverRouter.php?page=logout">LOGOUT</a>
        </div>

      </nav>
    </div>

  </div>
</div>
<script src="/js/bootstrap.bundle.js"></script>