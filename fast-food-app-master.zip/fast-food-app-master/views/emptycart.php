<?php

unset($_SESSION['cart']);

header("location: cart.php");