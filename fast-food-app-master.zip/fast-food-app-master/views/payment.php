<div class="container-fluid">
    <div class="row">

        <div class="card col-6 mb-3 shadow-sm text-success">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="..." class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <form action="" method="post">
                            <label for="number" class="form-label">Card Number</label>
                            <br>
                            <input type="text" class="form-control">
                            <label for="name" class="form-label">Cardholder name</label>
                            <br>
                            <input type="text" class="form-control">
                            <label for="name" class="form-label">Expiry Date</label>
                            <input type="date" class="form-control" id="date" />
                            <label for="securty" class="form-label">Security Number</label>
                            <input type="number" class="form-control" id="security" />
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-3  shadow-sm text-success gx-5">
            <div class="row g-0">
                <div class="col-12">
                    <div class="card-body">
                        <div class="card-text text-center"><H1>MPesa Pay Bill</H1></div>
                        <div class="card-text"><H1>Pay Bill:32313</H1></div>
                        <div class="card-text"><H3>Enter Transaction Code and Oder Id as the account number</H3></div>
                        <form action="" method="post">
                            <div class="row">
                            <div class="col-6 text-center">
                            <label for="number" class="form-label">Code</label>
                            <br>
                            <input type="text" class="form-control " style="width: 20rem;">
                            </div>
                            <div class="col-6 text-center">
                            <label for="number" class="form-label">Oder Id</label>
                            <br>
                            <input type="text" class="form-control " style="width: 20rem;">
                            </div>
                            </div>

                            <input type="submit" value="submit" class="form-control mt-5 bg-success">
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>