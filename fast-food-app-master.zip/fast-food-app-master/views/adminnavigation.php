<div class="shadow-sm col-12">
  <div class="row">
<div class="col-12">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="adminRouter.php?page=adminDashboard">Profile</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="nav navbar-nav">
                <li class="active col"> <a href="adminRouter.php?page=Adminpayments"  class="btn btn-hover">Payments</a></li>
                <li class="active col"><a href="adminRouter.php?page=AdminHotels"  class="btn btn-hover">Hotels</a></li>
                <li class="active col"><a href="adminRouter.php?page=admin_change_access" class="btn btn-hover">ACCESS CONTROL</a></li>
                <li class="active col"><a href="adminRouter.php?page=logout"  class="btn btn-warning">LOGOUT</a></li>
            </ul>
    </div>
  </div>
  
</nav>
</div>

</div>
</div>
<script src="/js/bootstrap.bundle.js"></script>
