<div class="shadow-sm col-12">
  <div class="row">
    <div class="col-12">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
          <a class="navbar-brand" href="hotelrouter.php?page=hotelDashboard">Profile</a>

          <a class="navbar-brand" aria-current="page" href="hotelrouter.php?page=hotelmanagerViewOders">View Oders</a>
          <a class="navbar-brand" href="hotelrouter.php?page=hotelManagerAddMeal">ADD MEAL</a>
          <a class="navbar-brand" href="hotelrouter.php?page=hotelManagerMeals">MEALS</a>
          <a class="navbar-brand" href="hotelrouter.php?page=hotelManagerViewPanyment">PAYMENTS</a>
          <a class="btn btn-primary" href="hotelrouter.php?page=logout">LOGOUT</a>
        </div>

      </nav>
    </div>

  </div>
</div>
<script src="/js/bootstrap.bundle.js"></script>