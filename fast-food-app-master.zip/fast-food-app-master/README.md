# ccs-project2
TO start this application succesfully
First excute the database dump,keep the auto increament values as they are.
After launging the php server,in the browser,search http://exampleadress/ccs-project2/
this will automaticaly open login page.From here you can navigate.